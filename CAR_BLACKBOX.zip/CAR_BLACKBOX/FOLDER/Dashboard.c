#include <xc.h>
#include "clcd.h"
#include "matrix_keypad.h"
#include "common.h"
#include "main.h"
#include "Dashboard.h"

uchar gear_index = 0;

void display_rpm()
{
	get_rpm();

	clcd_putch(rpm / 10 + '0', LINE2(14));
	clcd_putch(rpm % 10 + '0', LINE2(15));
}


void display_time(void)
{
    get_time();
    clcd_print(time, LINE2(0));
}


void display_event()
{
	clcd_print(event[event_index], LINE2(9));
}


void dashboard()
{
	clcd_print("                ", LINE1(0));
	clcd_print("                ", LINE2(0));
	
	while (1)
	{
		key = read_switches(STATE_CHANGE);

		clcd_print("  TIME  EVNT SP", LINE1(0));

		display_time();
		display_rpm();
		display_event();

		if (key == MK_SW2 && gear_index < 6)
		{
			event_index = ++gear_index;
			store_event();
		}

		if (key == MK_SW3 && gear_index > 1)
		{
			event_index = --gear_index;
			store_event();
		}

		if (key == MK_SW1)
		{
			event_index = 7;
			store_event();
		}

		if (key == MK_SW11)
			return;
	}
}
