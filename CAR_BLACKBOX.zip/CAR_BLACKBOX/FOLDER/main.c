#include <xc.h>
#include "Dashboard.h"
#include "password.h"
#include "menu.h"
#include "common.h"
#include "i2c.h"
#include "ds1307.h"
#include "external_eeprom.h"
#include "matrix_keypad.h"
#include "clcd.h"
#include "adc.h"
#include "uart.h"


void init_config()
{
	ADCON1 = 0x0F;

	init_clcd();
	init_matrix_keypad();
	init_adc();
	init_i2c();
	init_ds1307();
	init_uart();
}


void main()
{
	init_config();

	unsigned char pass = 0;

	while (1)
	{
		/*Default screen should be dashboard*/
		if (!pass)
			dashboard();
		
		if (key == MK_SW11)
			pass = 1;

		if (pass)
		{
			if (password_operation() == success)
				menu_page();

			pass = 0;
		}
	}
}
