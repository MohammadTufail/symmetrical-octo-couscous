#include <xc.h>

#include "clcd.h"
#include "matrix_keypad.h"
#include "common.h"
#include "main.h"
#include "uart.h"
#include "menu.h"
#include "ds1307.h"

#define DELAYIN	10000
#define DELAYO 6000
#define DELAY_1	4000

char menu_log[5][17] = {"View Log      ", "Clear Log     ", "Download Log   ","Set Time       ", "Change Password "};

uchar top = 0;

void menu_page()
{
	 uchar f = 0, up = 0, down = 0, enter = 0, prev_key = 0;
	 ulong next = 0, prev = 0;

	 clcd_print("*               ", LINE1(0));
	 clcd_print("                ", LINE2(0));

	 top = 0;

	 clcd_print(menu_log[top], LINE1(1));
	 clcd_print(menu_log[top + 1], LINE2(1));

	 while (1)
	 {
		  prev_key = f;
		  key = read_switches(LEVEL_CHANGE);

		  switch (key)
		  {
			   case MK_SW11:
					f = 11;
					next++;
					break;

			   case MK_SW12:
					f = 12;
					prev++;
					break;

			   default:
					f = 0;
		  }

		  if (!f)
		  {
			   if (prev_key == 11)
			   {
					if (next > DELAYIN)
						 enter = 1;

					else
						 up = 1;
			   }

			   else if (prev_key == 12)
			   {
					if (prev > (DELAYO+3000))
						 return;

					else
						 down = 1;
			   }
			   prev = 0;
			   next = 0;
		  }

		  if (up && top > 0)
		  {
			   top--;
		  }

		  if (down && top<4)
		  {
			   top++;
		  }

		  if (enter)
		  {
			   event_index = top + 9;

			   switch(top)
			   {
					case 0:
						 view_log();
						 break;

					case 1:
						 clear_log();
						 break;

					case 2:
						 download_log();
						 break;

					case 3:
						 set_time();
						 break;

					case 4:
						 change_password();
						 break;
			   }

			   up = 1;
			   top = 0;

			   enter = 0;
		  }

		  if (up)
		  {
			   clcd_putch('*', LINE1(0));
			   clcd_print(menu_log[top], LINE1(1));

			   clcd_putch(' ', LINE2(0));
			   clcd_print(menu_log[top+1], LINE2(1));

			   up = 0;
		  }

		  if (down)
		  {
			   clcd_putch(' ', LINE1(0));
			   clcd_print(menu_log[top-1], LINE1(1));

			   clcd_putch('*', LINE2(0));
			   clcd_print(menu_log[top], LINE2(1));

			   down = 0;
		  }
	 } /* while(1) */
}


/* To view the stored event in CLCD */
void view_log()
{
	 fetch_event();

	 clcd_print("LOGS            ", LINE1(0));
	 clcd_print("                ", LINE2(0));

	 uchar f = 0, prev_key = 0, index = 0, down = 0;
	 ulong prev = 0;

	 while (1)
	 {
		  clcd_print(log_fetch[index],LINE2(0));

		  prev_key = f;
		  key = read_switches(LEVEL_CHANGE);

		  switch (key)
		  {
			   case MK_SW11:
					f = 11;
					break;

			   case MK_SW12:
					f = 12;
					prev++;
					break;

			   default:
					f = 0;
		  }

		  if (!f)
		  {
			   if (prev_key == 11)
			   {
					if (index > 0)
						 index--;
			   }

			   else if (prev_key == 12)
			   {
					/* Long press */
					if (prev > (DELAYO-4100))
					{
						 store_event();
						 clcd_print("                ", LINE1(0));
						 clcd_print("                ", LINE2(0));
						 return;
					}

					else
					{
						 if (event_count > 1 && (index < event_count) && index < 9)
							  index++;
					}
			   }

			   prev = 0;
		  }
	 }
}


/* Clear the event data */
void clear_log()
{
	 extern char event_count;
	 extern char event_addr;
	 extern char event_flag;

	 event_count = 0;
	 event_addr = 0;
	 event_flag = 0;

	 store_event();

	 clcd_print("  DATA CLEARED  ", LINE1(0));
	 clcd_print("  SUCCESSFULLY  ", LINE2(0));

	 for(ulong i = 999999; i--;);

	 clcd_print("                ", LINE1(0));
	 clcd_print("                ", LINE2(0));
}


/* To change password */
void change_password()
{
	 char pass1[5], pass2[5];

	 clcd_print(" ENTER PASSWORD ", LINE1(0));
	 clcd_print("                ", LINE2(0));

	 enter_password(pass1);

	 clcd_print("REENTER PASSWORD", LINE1(0));
	 clcd_print("                ", LINE2(0));

	 enter_password(pass2);

	 /* If entered password matches, then update password */
	 if (my_strcmp(pass1, pass2) == 0)
	 {
		  store_event();

		  clcd_print("PASSWORD CHANGED", LINE1(0));
		  clcd_print("  SUCCESSFULLY  ", LINE2(0));

		  store_password(pass1);

		  for(ulong i = 999999; i--;);

		  clcd_print("                ", LINE1(0));
		  clcd_print("                ", LINE2(0));

		  return;
	 }

	 clcd_print("PASSWORD CHANGE", LINE1(0));
	 clcd_print("   IS FAILED   ", LINE2(0));

	 for(ulong i = 999999; i--;);

	 clcd_print("                ", LINE1(0));
	 clcd_print("                ", LINE2(0));
}


/* It is used for Password Operation */
void enter_password(char *pass)
{
	 uchar i = 0, f = 0, ch;

	 while (1)
	 {
		  key = read_switches(STATE_CHANGE);

		  if (key == MK_SW11)
			   ch = '1', f = 1;

		  if (key == MK_SW12)
			   ch = '0', f = 1;

		  if (f)
		  {
			   pass[i] = ch;
			   clcd_putch('*', LINE2(i++));
			   f = 0;
		  }

		  if (i>3)
		  {
			   pass[i] = '\0';
			   return;
		  }
	 }
}


/* To set time in RTC */
void set_time()
{
	 uchar f = 0, prev_key = 0, index = 0, down = 0, hr = 0, min = 0, sec = 0, bcd_time = 0;
	 ulong prev = 0, next = 0, blink = 0;

	 char tiempo[9] = "00:00:00";

	 clcd_print("TIME (HH:MM:SS) ", LINE1(0));
	 clcd_print("                ", LINE2(0));

	 while (1)
	 {
		  blink++;

		  if (blink < (DELAY_1 / 2))
			   clcd_print("  ", LINE2(index));

		  else if (blink > (DELAY_1 / 2))
			   clcd_print(tiempo, LINE2(0));

		  if (blink > DELAY_1)
			   blink = 0;

		  prev_key = f;
		  key = read_switches(LEVEL_CHANGE);

		  switch (key)
		  {
			   case MK_SW11:
					f = 11;
					next++;
					break;

			   case MK_SW12:
					f = 12;
					prev++;
					break;

			   default:
					f = 0;
		  }

		  if (!f)
		  {
			   if (prev_key == 11)
			   {
					if (next > DELAYIN)
					{
						 /* Writing Hour data to RTC */
						 bcd_time = (((hr / 10) << 4) | (hr % 10));
						 write_ds1307(HOUR_ADDR, bcd_time);

						 /* Writing Minute data to RTC*/
						 bcd_time = (((min / 10) << 4) | (min % 10));
						 write_ds1307(MIN_ADDR, bcd_time);

						 /* Writing Second data to RTC */
						 bcd_time = (((sec / 10) << 4) | (sec % 10));
						 write_ds1307(SEC_ADDR, bcd_time);

						 clcd_print("   Time Saved   ", LINE1(0));
						 clcd_print("  successfully  ", LINE2(0));

						 store_event();

						 for(ulong i = 999999; i--;);
						 clcd_print("                ", LINE2(0));
						 clcd_print("                ", LINE2(0));
						 return;
					}

					switch (index)
					{
						 case 0:
							  if (++hr > 23)
								   hr = 0;

							  tiempo[index] = hr/10 + '0';
							  tiempo[index + 1] = hr%10 + '0';

							  break;

						 case 3:
							  if (++min > 59)
								   min = 0;

							  tiempo[index] = min/10 + '0';
							  tiempo[index + 1] = min%10 + '0';

							  break;

						 case 6:
							  if (++sec > 59)
								   sec = 0;

							  tiempo[index] = sec/10 + '0';
							  tiempo[index + 1] = sec%10 + '0';

							  break;
					}
			   }

			   else if (prev_key == 12)
			   {
					if (prev > DELAYO-1000)
					{
						 clcd_print("                ", LINE1(0));
						 clcd_print("                ", LINE2(0));
						 return;
					}

					if (index < 6)
						 index = index + 3;

					else
						 index = 0;
			   }

			   prev = 0;
			   next = 0;
		  }
	 }
}

/* To display data in host system */
void download_log()
{
	 /* Fetch all the event and store */
	 fetch_event();

	 uchar index = 0;

	 clcd_print("  CONNECT HOST  ", LINE1(0));
	 clcd_print("                ", LINE2(0));

	 puts("SL   TIME  EV  SP\n\r");
	 puts("NO.\n\r");

	 while (1)
	 {
		  puts(log_fetch[index]);
		  puts("\n\r");

		  index++;

		  if (index > event_count)
		  {
			   puts("   DOWNLOADED\n\r");
			   puts("\n\r");
			   store_event();

			   clcd_print("  DOWNLOADED   ", LINE2(0));
			   for(ulong i = 999999; i--;);

			   clcd_print("                ", LINE1(0));
			   clcd_print("                ", LINE2(0));
			   return;
		  }
	 }
}
