#ifndef MAIN
#define MAIN


void my_strcpy(char *str_01, const char *str_02);
int my_strcmp(char *str_01, char *str_02);

void get_time();
void get_rpm();

void store_event();
void fetch_event();

void fetch_password();
void store_password (char *passwd);

#endif
