#ifndef DASHBOARD_H
#define DASHBOARD_H


void display_rpm();

void display_time();

void display_event();

void dashboard();

#endif
