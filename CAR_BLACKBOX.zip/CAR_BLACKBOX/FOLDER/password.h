#ifndef PASSWORD_H
#define PASSWORD_H

typedef unsigned char uchar;

void block_user();

uchar read_password();

uchar password_validate();

uchar password_operation();

#endif
