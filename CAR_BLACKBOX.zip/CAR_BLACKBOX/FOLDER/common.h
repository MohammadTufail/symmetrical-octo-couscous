#ifndef COMMON_H
#define COMMON_H

typedef unsigned char uchar;
typedef unsigned int uint;
typedef unsigned long ulong;


char event[13][3] = {"ON", "GR", "GN", "G1", "G2", "G3", "G4", "C ", "VL", "DL", "CL", "CP", "ST"};

char validate_password[5], password[5] = "1111";

char fetch_cond_pass[5] = "CM88";

/* validate_password[]	-> To store password entered by user
 * password[] 			-> Default password (very 1st time)
 * fetch_cond_pass[]	-> To store code for fetching password
 */

char log_fetch[10][17], log_store[17];

uchar key = 0, rpm = 0;

char event_index = 0, event_count = 0, event_addr = 0x00, event_flag = 0;
char time[9] = "00:00:00";

enum
{
	failure,
	success
};

#endif
