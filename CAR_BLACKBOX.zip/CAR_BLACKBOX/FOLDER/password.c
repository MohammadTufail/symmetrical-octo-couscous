#include <xc.h>
#include "clcd.h"
#include "matrix_keypad.h"
#include "main.h"
#include "common.h"
#include "password.h"

#define BLOCK_TIME	5000000
#define TIME_OVER	500000

uchar try_auth = 3;

void block_user()
{
	uchar count = 60, dash = 1;
	
	clcd_print("             ", LINE1(0));
	clcd_print("             ", LINE2(0));

	clcd_print("USER BLOCKED", LINE1(4));
	
	while(count)
	{
		clcd_putch('[', LINE2(0));
		clcd_putch(']', LINE2(11));

		clcd_putch(count/100 + '0', LINE2(13));
		clcd_putch((count/10) % 10 + '0', LINE2(14));
		clcd_putch(count% 10 + '0', LINE2(15));

		clcd_putch('-', LINE2(dash));

		for(ulong i = 1000000; i--;);

		count--;
		
		if (count % 6 == 0)
			dash++;
	}
}


uchar read_password()
{
	uchar i = 0, f = 0, ch;
	ulong wait = 0;

	clcd_print(" ENTER PASSWORD ", LINE1(0));
	clcd_print("                ", LINE2(0));
	
	while (1)
	{
		key = read_switches(STATE_CHANGE);
		
		if (wait >= TIME_OVER)
			return failure;

		if (key == MK_SW11)
			ch = '1', f = 1;

		if (key == MK_SW12)
			ch = '0', f = 1;
		
		if (!f)
		{
			wait++;
		}

		if (f)
		{
			validate_password[i] = ch;
			clcd_putch('*', LINE2(6+(i++)));
			f = 0;
			wait = 0;
		}

		/* Read 4 character */
		if (i>3)
		{
			validate_password[i] = '\0';
			return success;
		}
	}
}


uchar password_validate()
{
	for (uchar i = 0; i<4; i++)
	{
		if (validate_password[i] != password[i])
			return failure;
	}

	return success;
}


uchar password_operation()
{
	fetch_password();

	while (1)
	{
		if (read_password() == success)
		{
			if (password_validate() == success)
			{
				try_auth = 3;
				return success;
			}

			/* Authentication is allowed for 3 times only in case of wrong password*/
			else if (--try_auth)
			{
				clcd_print("                ", LINE1(0));
				clcd_print("                ", LINE2(0));

				clcd_print("Wrong Password", LINE1(0));
				clcd_putch(try_auth + '0', LINE2(0));
				clcd_print(" Attempts Left", LINE2(1));

				for(ulong i = 100000; i--;);
			}

			/* If all attempts are failed then put the system in block the user for few second */
			if (!try_auth)
			{
				block_user();
				try_auth = 3;
			}
		}

		else
		{
			try_auth = 3;
			return failure;
		}
	}
}
