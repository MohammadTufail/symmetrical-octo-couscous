#include <xc.h>
#include "clcd.h"
#include "ds1307.h"
#include "i2c.h"
#include "main.h"
#include "common.h"
#include "external_eeprom.h"
#include "adc.h"

void my_strcpy(char *str_01, const char *str_02)
{
	char i = 0;
	
	for(; str_02[i]; i++)
	{
		str_01[i] = str_02[i];
	}

	str_01[i] = '\0';
}


int my_strcmp(char *str_01, char *str_02)
{
	char i = 0;

	for(; str_01[i] && str_02[i]; i++)
	{
		if (str_01[i] != str_02[i])
			return str_01[i] - str_02[i];
	}

	return 0;
}


uchar clock_reg[3];
uchar calender_reg[4];

void get_time()
{
    clock_reg[0] = read_ds1307(HOUR_ADDR);
    clock_reg[1] = read_ds1307(MIN_ADDR);
    clock_reg[2] = read_ds1307(SEC_ADDR);

    if (clock_reg[0] & 0x40)
    {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
        time[1] = '0' + (clock_reg[0] & 0x0F);
    }

    else
    {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
        time[1] = '0' + (clock_reg[0] & 0x0F);
    }

    time[2] = ':';
    time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
    time[4] = '0' + (clock_reg[1] & 0x0F);
    time[5] = ':';
    time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
    time[7] = '0' + (clock_reg[2] & 0x0F);
    time[8] = '\0';
}



void get_rpm()
{
    uint adc_reg;

    adc_reg = (read_adc(CHANNEL4) / 10);
    if(adc_reg >= 100)
    {
        adc_reg = 99;
    }
    rpm = adc_reg;
}



void store_event()
{
	get_time();
	get_rpm();

	if (event_flag > 9)
	{
		event_flag = 0;
		event_addr = 0x00;
	}
	
	if (event_count < 9)
	{
		event_count++;
	}

	log_store[0]  = event_flag + '0';
	log_store[1] = ' ';
	
	my_strcpy(log_store + 2, time);
	log_store[10] = ' ';
	
	my_strcpy(log_store + 11, event[event_index]);
	log_store[13] = ' ';

	log_store[14] = rpm/10 + '0';
	log_store[15] = rpm%10 + '0';
	
	log_store[16] = '\0';
	

	for (uchar i = event_addr, j = 0; event_addr <= i + 0x0F ; event_addr++, j++)
	{
		write_ex_eeprom(event_addr, log_store[j]);
	}

	event_flag++;
}


void fetch_event()
{
	uchar i, j, read_addr = 0x00;

	for(i = 0; i<10; i++)
	{

		if (i > event_count)
			return;

		for(j=0; j<16; j++)
		{
			log_fetch[i][j] = read_ex_eeprom(read_addr);
			read_addr++;
		}

		log_fetch[i][j] = '\0';
	}
}


#define FETCH_CODE_ADDR		0xFB
#define PASSWORD_ADDR		0xA0

void fetch_password()
{
	char flag = 0, i =0;
	
	for (uchar addr = FETCH_CODE_ADDR; i < 4; addr++, i++)
	{
		if (fetch_cond_pass[i] != read_ex_eeprom(addr))
		{
			flag = 1;
			break;
		}
	}
	
	if (flag)
	{
		store_password(password);
		return;
	}
	
	i = 0;

	for (uchar addr = PASSWORD_ADDR; i < 4; addr++, i++)
	{
		password[i] = read_ex_eeprom(addr);
	}
	password[i] = '\0';
}



void store_password (char *passwd)
{
	for (uchar addr = PASSWORD_ADDR, i=0; i < 4; addr++, i++)
	{
		write_ex_eeprom(addr, passwd[i]);
	}

	for (uchar addr = FETCH_CODE_ADDR, i=0; i < 4; addr++, i++)
	{
		write_ex_eeprom(addr, fetch_cond_pass[i]);
	}
}
