#ifndef MENU_H
#define MENU_H

void menu_page();

void view_log();

void clear_log();

void change_password();

void enter_password(char *pass);

void set_time();

void download_log();

#endif
