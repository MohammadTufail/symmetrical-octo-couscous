#ifndef Ex_eeprom
#define Ex_eeprom

#define EE_SLAVE_READ		0xA1
#define EE_SLAVE_WRITE		0xA0


void write_ex_eeprom(unsigned char address,  unsigned char data);
unsigned char read_ex_eeprom(unsigned char address);

#endif
