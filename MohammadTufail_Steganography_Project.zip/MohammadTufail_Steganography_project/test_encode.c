/*
Name: MohammadTufail A Akkalkot
Date: 31/03/2023
Project: LSB Image Steganography
*/


#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

int main(int argc , char *argv[])                        //command line arguments
{
		  if( check_operation_type(argv)  == e_encode )             //condition to check encode or not
		  {
			   if( argc >= 4 )                                   //condition true then check number of arguments
			   {
			   printf("selected encoding\n");
		
			   EncodeInfo encInfo ;                             //declare the strucuture pointer

	           if( read_and_validate_encode_args(argv , &encInfo ) == e_success )    //call the function to check the command arguments
	           {
		           printf("Input is successfully stored\n");
				   
				   if( do_encoding( &encInfo ) == e_success )                    //call encoding function and pass the encode structure
				   {
		               printf("secret data has successfully stored\n");

					   return 0 ;                                             
				   }
			       else
				    	printf("Input is not successfully store\n");             //encoding part any fail then print error message
	           }
	           else
		           printf(" Input  is not success store\n");                  //if condition false then print error
			   }
			   else
		  	   printf("Invalid Input, Enter the minimum 4 or more arguments\n"); 
		  }
		  else if( check_operation_type( argv ) == e_decode )                  //condition to check decode or not 
		  {
			   printf("selected decoding\n");
			   if ( argc >= 3 )                                                  //check no of argument 
			   {
			   decodeInfo decInfo ;                                            //if condition true then declare the decoding sturcture variable

	           if( read_and_validate_decode_args(argv , &decInfo ) == e_success )   // check read and validate for decoding
	           {
		           printf("Input is successfully stored\n");
				   if( do_decoding( &decInfo ) == e_success )                     //call the decoding function 
	               {
		               printf("secret data has successfully copy\n");

					   return 0 ;                                                
				   }
			       else
				    	printf(" secret data not successfully store\n");
	           }
	           else
		           printf(" Input  is not success store\n");                      //condition is false print the error
			   }
			   else
					printf("Enter 3 or more arguments\n");
		  }
		  else 
	           printf("please pass the -e or -d only\n"); 

		  return 1 ;
}


OperationType check_operation_type( char **argv)                 //check it is encode or decode 
{
   if( strcmp( argv[1] , "-e" ) == 0 )                //check it is encode or not
   {
		return e_encode ;
   }
   else if( strcmp(argv[1] , "-d") == 0 )            //check it is decode or not 
		return e_decode ;
   else
		return e_unsupported ;                       
}     
