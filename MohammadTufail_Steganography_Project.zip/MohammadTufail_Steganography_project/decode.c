#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "decode.h"
#include "types.h"
/* find arguments present or not */
Status read_and_validate_decode_args(char **argv , decodeInfo *decInfo ) 
{
	 int i ;

	 if( !strcmp( strchr( argv[2] , '.' ) , ".bmp") )
	 {
		  printf("Info: bmp file is present\n");
		  printf("Done\n");
		  decInfo -> src_image_fname = argv[2] ;
	 }
	 else 
	 {
		  printf("bmp file is not present\n");

		  return e_failure;
	 }

	 if( argv[3] != NULL )
	 {
		  decInfo -> secret_fname= argv[3] ;

		  strcpy( decInfo-> extn_secret_file , strchr( argv[3] , '.' )) ;
		  printf("Info: File name is present\n");
		  printf("Done\n");

	 }
	 else
	 {
		  printf("File name is not present,declare one name\n");

		  strcpy (decInfo -> doub_fname, "dup");

		  printf("%s\n", decInfo->doub_fname) ;
		  decInfo -> secret_fname= NULL ;

		 // decInfo->extn_secret_file[0] = '\0' ;
	 }

	 return e_success;
}

Status do_decoding(decodeInfo *decInfo ) 
{
	 if( open_files_decode( decInfo ) == e_success )
	 {
		  printf("Info: file successfully opened\n");
		  printf("Done\n");
		  if( decode_magic_string( decInfo ) == e_success )
		  {
			   printf("Info: Magic string is same\n");
			   printf("Done\n");
			   int extr_size ;

			   if(decode_secret_file_extn_size( &extr_size , decInfo) == e_success )
			   {
					printf("Info: Found the exten size %d\n", extr_size );
					printf("Done\n");
					if(decode_secret_file_extn( decInfo->extn_secret_file , decInfo , extr_size ) == e_success )
					{
						 printf("Info: File extension is found\n");
						 printf("Done\n");
						 if(decode_secret_file_size( &decInfo->size_secret_file , decInfo ) == e_success)
						 {
							  printf("Info: File size is found %d\n", decInfo->size_secret_file );
							  printf("Done\n");
							  if(decode_secret_file_data( decInfo ) == e_success)
							  {
								   printf("Info: File data is copied\n");
								   printf("Done\n");
								   return e_success;
							  }
							  else
							  {
								   printf("Info: File data not copied\n");
								   return e_failure;
							  }
						 }
						 else
						 {
							  printf("Info: File size not found\n");
							  return e_failure;
						 } 
					}
					else
					{
						 printf("Info: File extension not found\n");

						 return e_failure;
					}
			   }
			   else
			   {
					printf(" Not Found the exten size\n");

					return e_failure;
			   }
		  }
		  else
		  {
			   printf("Magic string is not same\n");

			   return e_failure;
		  }
	 }
	 else
	 {
		  printf("File not successfully opened\n");
		  return e_failure;
	 }
}

Status open_files_decode(decodeInfo *decInfo)
{
    // Src Image file
    decInfo->fptr_src_image = fopen(decInfo->src_image_fname, "r");
    // Do Error handling
    if (decInfo->fptr_src_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->src_image_fname);

    	return e_failure;
    }


    return e_success;
}

Status decode_magic_string( decodeInfo *decInfo )
{
	 char arr[2] ;

	 fseek( decInfo->fptr_src_image , 54 , 0 );

	  if ( decode_data_to_image( arr , 2 , decInfo ) == e_success)
	  {
		   if(!strcmp( arr , "!*"))
		   {
				return e_success;
		   }
		   else
				return e_failure;
	  }
	  else
		   return e_failure;

}

Status decode_data_to_image(char *data, int size, decodeInfo *decInfo )
{
	 int i ;

	 printf("%ld\n",ftell(decInfo->fptr_src_image));

	 for(i= 0 ; i < size ; i++ ) 
	 {
		  fread( decInfo->image_data , 8 , 1, decInfo->fptr_src_image );

		  decode_byte_to_lsb( &data[i], decInfo->image_data ) ;
	
		  printf("%c", data[i]);
	 }
	 printf("\n");

	 printf("%ld\n",ftell(decInfo->fptr_src_image));

	 return e_success;
}
Status decode_byte_to_lsb(char *data, char *image_buffer)
{
	 int i ;

	 data[0]= '\0' ;

	 for(i= 0 ; i < 8 ;i++ )
	 {
		  data[0]= (( image_buffer[i] & 1 ) << (7 - i)) |data[0] ;
	 }

	 if( data[0] != '\0' )
		  return e_success;
	 else
		  return e_failure;
}
 Status decode_secret_file_extn_size( int *size , decodeInfo *decInfo)
{
	 if (decode_secret_file_size( size , decInfo) == e_success)
	 {
		  return e_success;
	 }
	 else
	 {
		  return e_failure;
	 }
}
Status decode_secret_file_size(int *file_size, decodeInfo *decInfo)
{
	 int i , a= 0;

	 *file_size= 0 ;

	 printf("%ld\n", ftell( decInfo-> fptr_src_image));

	 fread( decInfo-> image_data_size , 32 , 1 , decInfo->fptr_src_image ) ;

	 for(i= 0 ; i < 32 ; i++ )
	 {
		  a= decInfo->image_data_size[i] & 1 ;
		  *file_size= *file_size | (a << (31-i)) ;
	 }
	 
	 printf("%ld\n", ftell( decInfo-> fptr_src_image));

	 if(*file_size)
		  return e_success;
	 else
		  return e_failure;
}

Status decode_secret_file_extn( char *file_extn, decodeInfo *decInfo , int size)
{
	 if(decode_data_to_image( file_extn , size , decInfo ) == e_success ) 
	 {
		  printf("%s\n", file_extn);

		  if ( decInfo->secret_fname == NULL )
		  {
			   strcat ( decInfo->doub_fname , file_extn );

			  
		  }
		  else
			  strcpy( decInfo-> doub_fname , decInfo->secret_fname );

		  printf("%s\n", decInfo->doub_fname); 

	
		  decInfo->fptr_secret = fopen(decInfo-> doub_fname , "w");
    
	
		  // Do Error handling
    
	
		  if (decInfo->fptr_secret == NULL)
		  {
			   perror("fopen");
    	       fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->secret_fname);

    	       return e_failure;
		  }
				   return e_success ;
	 }
	 else
	 {
		  return e_failure;
	 }
}
Status decode_secret_file_data(decodeInfo *decInfo)
{
	 char data[decInfo-> size_secret_file];

	 int i ;
	  if ( decode_data_to_image( data , decInfo-> size_secret_file , decInfo ) == e_success)
	  {
		   for(i= 0 ; i < decInfo->size_secret_file ; i++ )
		   {
				fputc( data[i] , decInfo->fptr_secret ) ;
		   }
		   return e_success;
	  }
	  else
		   return e_failure;
}
