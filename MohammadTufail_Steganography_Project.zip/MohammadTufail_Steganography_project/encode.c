#include <string.h>
#include <stdio.h>
#include "encode.h"
#include "types.h"

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}
/*To create read and validate function to find command line argument is currect or not */

Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)        
{
	 if(! strcmp(strchr( argv[2] , '.' ) , ".bmp" ))                             //check the bmp file is present or not
	 {
		  printf("bpm file is entered\n");
		  encInfo->src_image_fname= argv[2] ;
	 }
	 else
	 {
		  printf("Error, third argument is not bmp file\n");

		  return e_failure ;
	 }

	 if(argv[3] != NULL)                                                          //check secret file is present or not
	 {
		  char *ptr ;
		  if((ptr= strchr( argv[3] , '.')) != NULL )
		  {
			   strcpy( encInfo->extn_secret_file , ptr ) ;
		  printf("Text file is present\n");

		  encInfo->secret_fname= argv[3] ;
		  }
		  else
			   return e_failure;
	 }
	 else
	 {
		  printf("Error, text is not present\n");

		  return e_failure ;
	 }

	 if( argv[4] != NULL )
		  encInfo->stego_image_fname= argv[4] ;
	 else
	 {
		  encInfo->stego_image_fname= "dup_stieg.bmp";
	 }
	 return e_success ;
}

/* do_encoding definition */

Status do_encoding(EncodeInfo *encInfo)
{
	 if( open_files( encInfo ) == e_success )
	 {
		  printf("Info: File is opened successfully\n");
	 	  printf("Done\n");
		  if( check_capacity( encInfo ) == e_success )
		  {
			   printf("Info: Capacity is successfully checked\n");
			   printf("Done\n");
			   if( copy_bmp_header( encInfo -> fptr_src_image , encInfo -> fptr_stego_image ) == e_success )
			   {
					printf("Info: bmp Header copied successfully\n");
					printf("Done\n");
					if( encode_magic_string("!*" , encInfo ) == e_success ) 
					{
						 printf("Info: magic string successfull store\n");
						 printf("Done\n");
						 if( encode_secret_file_extn(encInfo -> extn_secret_file , encInfo) == e_success )
						 {
							  printf("Info: secret file extn store successfully\n");
							  printf("Done\n");
							  if( encode_secret_file_data( encInfo ) == e_success ) 
							  {
								   printf("Info: secret file data stored successfully\n");
								   printf("Done\n");
								   if( copy_remaining_img_data( encInfo-> fptr_src_image , encInfo -> fptr_stego_image ) == e_success)
								   {
										printf("Info: Remaining image data stored successfully\n");
										printf("Done\n");
										return e_success;
								   }
								   else
								   {
										printf("Info: Remaining image data was not stored successfully\n");

										return e_failure;
								   }
							  }
							  else
							  {
								   printf("Info: secret file data was not stored successfully\n");

								   return e_success;
							  } 
						 }
						 else
						 {
							  printf("Info: secret file extn not successfully store\n");
							  return e_failure ;
						 }
					}
					else
					{
						 printf("Info: password not successfully store\n");

						 return e_failure;
					}
			   }
			   else
			   {
					printf("Info: bmp header not successfully copy\n");
					return e_failure;
			   }
		  }
		  else
		  {
			   printf("Info: Capacity is not Same\n");

			   return e_failure ;
		  }
	 }
	 else
	 {
		  printf("Info: Opening of file is failed\n");

		  return e_failure ;
	 }
}

Status check_capacity(EncodeInfo *encInfo)
{
	 if( get_image_size_for_bmp( encInfo->fptr_src_image  ) >  get_file_size(encInfo, encInfo->fptr_secret ) )
	 {
		  printf("Image size is more the file size\n");

		  return e_success ;
	 }
	 else
	 {
		  printf("Error, Image size is less\n");

		  return e_failure ;
	 }
}

uint get_file_size(EncodeInfo *encInfo ,FILE *fptr)
{
	 int magic_len , file_len  ;
	 magic_len= strlen ("!*")  ;
	  fseek( fptr , 0 , 2 ) ;
	 encInfo->size_secret_file= ftell(fptr)  ;
	  rewind( fptr) ;
	 return (magic_len + encInfo->size_secret_file + 4 + 4 +4 ) * 8;

}
/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return e_failure;
    }

    // Siecret file
    
	encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    
	// Do Error handling
    
	if (encInfo->fptr_secret == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return e_failure;
    }

    // Stego Image file
    
	encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    
	// Do Error handling
    
	if (encInfo->fptr_stego_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

    	return e_failure;
    }

    // No failure return e_success 

    return e_success;
}

Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
	 int i ;

	 char ima_copy_byte[1] ;

	 rewind ( fptr_src_image );
	 
	 rewind ( fptr_dest_image );

	 for (i= 0 ; i < 54 ; i++ )
	 {
		  if( (fread (ima_copy_byte , 1 , 1, fptr_src_image )) == 0) 
			   return e_failure;

		  if( (fwrite( ima_copy_byte, 1 , 1 , fptr_dest_image )) == 0) 
			   return e_failure;
	 }

	 return e_success ;
}

Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
	 int i;

	 EncodeInfo encInfo ;

	 for(i= 0 ; i < size ; i++ )
	 {
		  fread( encInfo.image_data , 1 , 8 , fptr_src_image );

		  encode_byte_to_lsb( data[i] , encInfo.image_data ) ;
		 
		  fwrite( encInfo.image_data , 1 , 8 , fptr_stego_image );
	 }

	 return e_success;
}
Status encode_magic_string( char *magic_string, EncodeInfo *encInfo )
{
	 if( encode_data_to_image(magic_string, strlen("!*") ,encInfo -> fptr_src_image, encInfo -> fptr_stego_image) == e_success )
	 {
		  return e_success;
	 }
	 else
		  return e_failure ; 
}

Status encode_byte_to_lsb(char data, char *image_buffer)
{
	 int i ;

	 for(i= 0 ; i < 8 ; i++ )
	 {
	   image_buffer[i]= (( image_buffer[i] & (~1)) | ((data & ( 1 <<(7 - i))) >> (7 - i)));
	 }
	 return e_success ;
}
Status encode_secret_file_extn( char *file_extn, EncodeInfo *encInfo)
{
	 if( encode_secret_file_size( strlen( file_extn) , encInfo) == e_success)
	 {
		  printf("extn size store successfully\n");
	 
	 if( encode_data_to_image( file_extn , strlen( file_extn ), encInfo ->fptr_src_image, encInfo ->fptr_stego_image) == e_success)
	 {
		  return e_success;
	 }
	 }
}
Status encode_secret_file_size(int file_size, EncodeInfo *encInfo)
{
	 int i ;

	 fread( encInfo->image_data_size , 1 , 32 , encInfo->fptr_src_image) ;
	 for(i= 0 ; i < 32 ; i++ )
	 {
		 encInfo->image_data_size[i]= (( encInfo->image_data_size[i] & (~1)) | (( file_size & ( 1 <<(31 - i))) >> (31 - i)));

	 }

	 fwrite( encInfo->image_data_size , 1 , 32 , encInfo-> fptr_stego_image );

	 return e_success ;
}

Status encode_secret_file_data(EncodeInfo *encInfo)
{
	 int i ;
	 if( encode_secret_file_size( encInfo->size_secret_file , encInfo ) == e_success)
	 {
		  char data[encInfo->size_secret_file];
		  rewind( encInfo->fptr_secret) ;
		  for(i=0 ; (data[i]=fgetc( encInfo->fptr_secret )) != EOF ; i++) ; 
		  if( encode_data_to_image( data , encInfo->size_secret_file , encInfo ->fptr_src_image, encInfo ->fptr_stego_image) == e_success)
		  {
			   return e_success;
		  }
	 }
}

Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
	 char ch[1] ;

	 while( fread(ch , 1 , 1 , fptr_src ) > 0)
		 {
		  fwrite( ch , 1 , 1 , fptr_dest );
		 }

	 return e_success;
}
